cp -r  $BUILD_DIR/images/jre/* java
rm -fr java/a
mkdir java/a
cp $BUILD_DIR/support/native/java.base/libfdlibm.a java/a
mv `find java/lib -name '*.a'` java/a
mv `find java/lib -name '*.symbols'` java/a
cat java/a/lib{java,jvm,jimage,net,nio,verify,zip}.symbols > java/a/release.symbols

cp -r  $BUILD_DIR/images/jre/conf/ conf

rm -fr JavaLauncher.framework
cp -r  $BUILD_DIR/jdk/frameworks/JavaLauncher/JavaLauncher.framework .
