
rm -fr JavaLauncher.framework/*
rm -fr java/{ASSEMBLY_EXCEPTION,THIRD_PARTY_README,COPYRIGHT,LICENSE,README,THIRDPARTYLICENSEREADME.txt,Welcome.html,a,conf,jar,lib,release}
rm -fr conf

