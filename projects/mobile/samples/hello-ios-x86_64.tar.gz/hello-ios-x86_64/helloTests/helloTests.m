//
//  helloTests.m
//  helloTests
//
// Copyright (c) 2013, Oracle and/or its affiliates. All rights reserved.
// DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
//
// This code is free software; you can redistribute it and/or modify it
// under the terms of the GNU General Public License version 2 only, as
// published by the Free Software Foundation.  Oracle designates this
// particular file as subject to the "Classpath" exception as provided
// by Oracle in the LICENSE file that accompanied this code.
//
// This code is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
// version 2 for more details (a copy is included in the LICENSE file that
// accompanied this code).
//
// You should have received a copy of the GNU General Public License version
// 2 along with this work; if not, write to the Free Software Foundation,
// Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
//
// Please contact Oracle, 500 Oracle Parkway, Redwood Shores, CA 94065 USA
// or visit www.oracle.com if you need additional information or have any
// questions.
//
// Example of how to run iOS test from command line:
//
// xcodebuild test -project Helloarm.xcodeproj -scheme HelloWorld \
//   -destination 'platform=iOS,id=8ab3b9fd6d2e954611f4e01a127742627e15dbce'
//
// Substitute your applications Scheme name for HelloWorld
// and you devices id.

#import <UIKit/UIKit.h>
#import <XCTest/XCTest.h>
#import "JavaLauncher/JavaLauncher.h"

static void javaLauncherCallback(const char *exception_msg, int error_code, void *app_data)
{
    NSLog(@"JavaTestTests::javaLauncherCallback: Received exception.");
    NSLog(@"JavaTestsTests::javaLauncherCallback: Exception msg: %@.",
          [NSString stringWithUTF8String: exception_msg]);
}

static JavaArgs *java_args = NULL;

@interface helloTests : XCTestCase

@end

@implementation helloTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    if (java_args == NULL) {
        NSBundle *bundle = [NSBundle bundleForClass:self.class];
        java_args = [[JavaArgs alloc] init:bundle];
        java_args.callback = javaLauncherCallback;
        [JavaLauncher createJavaVM:java_args];
    }
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    
    NSTimeInterval sleepTime = 1000.0;

    [JavaLauncher performSelector:@selector(callJava:)
                       withObject:java_args];
    
    // Give the VM a chance to dump the interpreter and exit
    [NSThread sleepForTimeInterval:sleepTime];

}

//- (void)testPerformanceExample {
//    // This is an example of a performance test case.
//    [self measureBlock:^{
//        // Put the code you want to measure the time of here.
//    }];
//}

@end
